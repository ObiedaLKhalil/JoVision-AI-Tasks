# Chess Annotation > 2024-08-22 9:56am
https://universe.roboflow.com/chess-annotation/chess-annotation-trdak

Provided by a Roboflow user
License: CC BY 4.0

