# Chess Annotation > 2024-09-11 8:00am
https://universe.roboflow.com/chess-annotation/chess-annotation-trdak

Provided by a Roboflow user
License: CC BY 4.0

